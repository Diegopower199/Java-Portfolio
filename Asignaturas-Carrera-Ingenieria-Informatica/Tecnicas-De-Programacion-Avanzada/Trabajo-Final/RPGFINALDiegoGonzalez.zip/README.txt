Autor: Diego Gonzalez Sanz
Fecha: 14/12/2021
Título: Call Of Duty Black Ops II
 
Abstract(<300 palabras): 
Él juego está ambientado en la Guerra Fría del siglo XXI. En él juego puedes elegir la skin que usted quiera, él rol que harás en la partida y las armas quieras tener, dependiendo del rol tendrá unas armas u otras.
Él rol “Objective” como arma principal las armas son fusiles de asalto y subfusiles y la arma secundaria solo son pistolas. Él rol “Slayer” como arma principal las armas son subfusiles y escopetas y la arma secundaria son pistolas y  lanzacohetes. Él rol “Defensive” como arma principal las armas son ametralladoras ligeras y fusiles de francotirador y la arma secundaria son pistolas y especiales.
Es un juego de equipo de 4 vs 4, que deben matar a los rivales, para ganar la partida deben matar 20 veces a los enemigos o se acabará él tiempo que es 3 minutos por cada partida. Cada jugador tiene una vida de 100 y las armas dependiendo de cual sea tendrá un daño u otro. Además tenemos 12 mapas para elegir. Los equipos se van a distinguir entre rojo y azul. Solo se podrá crear un único personaje. 
 
Fuentes empleadas (si has cogido código de otros lados, citas y links): 
https://www.youtube.com/watch?v=dEKs-3GhVKQ&list=PLah6faXAgguMnTBs3JnEJY0shAc18XYQZ
https://censorcosmico.blogspot.com/2014/04/graficos-en-2d-insertar-una-imagen.html
https://www.javatpoint.com/post/java-timer-scheduleatfixedrate-method
https://www.lawebdelprogramador.com/foros/Java/249738-UrgenTe-Botones-transparentes.html
http://www.chuidiang.org/java/layout/GridBagLayout/GridBagLayout.php
https://censorcosmico.blogspot.com/2010/03/crear-grupo-de-botones-buttongroup.html
http://chuwiki.chuidiang.org/index.php?title=ActionListener
https://programandoointentandolo.com/2013/10/como-generar-numeros-aleatorios-en-java.html
https://www.it-swarm-es.com/es/java/completar-swing-jcombobox-de-enum/967092721/
Este aun no lo he utilizado
https://codigosparadesarrolladores.blogspot.com/2019/04/Agregar-imagen-de-fondo-a-un-JFrame.html
https://www.it-swarm-es.com/es/java/como-leer-un-archivo-de-un-archivo-jar/968499766/
https://stackoverflow.com/questions/17002906/trying-to-load-image-using-imageio-readclass-getresourceurl-but-getresource
 

 
Otros: comentarios que deba tener en cuenta la persona que ejecute el código, necesidades de librerías, flags de compilación, etc:
En la parte de la interfaz grafica (donde se crea el personaje), debes marcar todas las opciones (Los 2 radio button, los 3 combo box y un nombre en el text field) para que se pueda crear un personaje. 
Ademas tienes 2 opciones que puedes guardar en el momento que quieras todo lo introducido en la parte de la interfaz grafica y puedes salir de la aplicacion de inmediato dando al boton de salir. 

Cuando estas en la parte del juego tienes 180 segundos (3 minutos) para jugar la partida y si ese tiempo se completa el programa se cerrará de inmediato. 
 
Necesidades de librerías: JRE System Library [JavaSE-1.8]
 
